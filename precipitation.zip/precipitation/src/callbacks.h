#include <gtk/gtk.h>


void
on_afficher_precipitation_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_precipitation_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_precipitation_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_precipitation_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_precipitation_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_modif_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_modif_precipitation_clicked (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_suppression_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chercher_annee_seche_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);
