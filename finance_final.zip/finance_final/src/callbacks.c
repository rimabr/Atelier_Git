#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "finance.h"

int choix[]={0,1};

void
on_ajouter_transac_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_transac ;

GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"acceuil_finance");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"modif_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"supprimer_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"affichage_exep");
gtk_widget_destroy(windowf5);

ajouter_transac=create_ajout_transac();
gtk_widget_show (ajouter_transac);
}

////////////////////////////////////////////////////////////////////////
void
on_modifier_transac_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *modifiertransac ;

GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"acceuil_finance");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"supprimer_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"affichage_exep");
gtk_widget_destroy(windowf5);

modifiertransac=create_modif_transac();
gtk_widget_show (modifiertransac);
}

////////////////////////////////////////////////////////////////////////
void
on_supprimer_transac_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *supprimertransac ;

GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"acceuil_finance");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"modif_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"affichage_exep");
gtk_widget_destroy(windowf5);

supprimertransac=create_supprimer_transac();
gtk_widget_show (supprimertransac);
}

////////////////////////////////////////////////////////////////////////
void
on_afficher_transac_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowaffich ;
GtkWidget *fenetre_ajout;
GtkWidget *treeview1;

fenetre_ajout=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(fenetre_ajout);
windowaffich=lookup_widget(objet,"affichage_transac");

GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"acceuil_finance");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"modif_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"supprimer_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"affichage_exep");
gtk_widget_destroy(windowf5);

windowaffich=create_affichage_transac();
gtk_widget_show (windowaffich);

treeview1=lookup_widget(windowaffich,"treeview1");
afficher_transac(treeview1);
}

////////////////////////////////////////////////////////////////////////
void
on_button_retour1_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal2 ;

GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"modif_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"supprimer_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"affichage_exep");

menuprincipal2=create_acceuil_finance();
gtk_widget_show (menuprincipal2);
}

////////////////////////////////////////////////////////////////////////
void
on_button_valider_transac_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE* f;transaction T; char ch[50];
int j,m,a,mon; char chj[20],chm[20],cha[20],chs[20],text[20];
   
    GtkWidget *C,*N,*O,*MON,*J,*M,*A,*E,*pt,*Ty;
    GtkWidget *ajouter_transac;
    ajouter_transac=lookup_widget(objet,"ajout_transac");
    C=lookup_widget(objet,"entry_code_transac");
    N=lookup_widget(objet,"entry_nom_transac");
    MON=lookup_widget(objet,"entry_montant_facture");
    O=lookup_widget(objet,"entry_objet_transac");
    J=lookup_widget(objet,"spinbutton_jour");
    M=lookup_widget(objet,"spinbutton_mois");
    A=lookup_widget(objet,"spinbutton_annee");
    Ty=lookup_widget(objet,"combobox_type_facture");


    pt=lookup_widget (objet ,"sortie_ajouter_transac");
j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(J)); sprintf(chj,"%d",j);
m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(M)); sprintf(chm,"%d",m);
a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(A)); sprintf(cha,"%d",a);
strcpy(T.code_transac,gtk_entry_get_text(GTK_ENTRY(C)));
strcpy(T.nom,gtk_entry_get_text(GTK_ENTRY(N)));
strcpy(T.objet,gtk_entry_get_text(GTK_ENTRY(O)));
strcpy(T.montant,gtk_entry_get_text(GTK_ENTRY(MON)));
strcpy(T.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Ty)));


strcpy(T.date.jour,chj);
strcpy(T.date.mois,chm);
strcpy(T.date.annee,cha);


		
	
    
	    if (T_trouve(T.code_transac)==0)
		{ 
		    ajouter_transaction (T);
		    sprintf(ch,"Ajout reussi");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}
	    else
		{
		    sprintf(ch,"ERREUR: transaction deja existant");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		}
}

////////////////////////////////////////////////////////////////////////
void
on_button_chercher_modif_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* identif,*pt; char id [25],ch[40]; int test;
char ch1[20],ch2[20],ch3[20],ch4[20],ch5[20],ch6[20],ch7[20],ch8[20];
GtkWidget *ty, *n, *jj, *mm, *aa, *ob, *mon;
FILE* f;
f=fopen("transac.txt","r");
identif=lookup_widget(objet,"entry_code_modif");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(identif)));   
ty=lookup_widget(objet,"sortie_type_transac");
n=lookup_widget(objet,"sortie_nom_transac");
jj=lookup_widget(objet,"sortie_jour_transac");
mm=lookup_widget(objet,"sortie_mois_transac");
aa=lookup_widget(objet,"sortie_annee_transac");
ob=lookup_widget(objet,"sortie_objet_transac");
mon=lookup_widget(objet,"sortie_montant_transac");
pt=lookup_widget(objet,"sortie_rechercher_modif");

	if (f!=NULL)
{

         while (fscanf (f, "%s %s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7,ch8)!=EOF)
            {
	if (strcmp(id,ch1)==0)
	{
			sprintf(ch,"Identifiant existant!");
		    	gtk_label_set_text(GTK_LABEL(pt),ch);

			gtk_label_set_text(GTK_LABEL(n),ch2);
			gtk_label_set_text(GTK_LABEL(ty),ch8);
			gtk_label_set_text(GTK_LABEL(ob),ch6);
			gtk_label_set_text(GTK_LABEL(jj),ch3);
			gtk_label_set_text(GTK_LABEL(mm),ch4);
			gtk_label_set_text(GTK_LABEL(aa),ch5);
			gtk_label_set_text(GTK_LABEL(mon),ch7);
		}}
	fclose(f);
		}
	    else
		{
		    sprintf(ch,"ERREUR: identifiant non existant.");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		} 

}

////////////////////////////////////////////////////////////////////////
void
on_button_valider_modif_transac_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
char ch_element[20],ch_value[20],id[20],ch[50]; int e,test;

	GtkWidget *element,*val,*identif,*pt;

pt=lookup_widget(objet,"sortie_information_modif");
identif=lookup_widget(objet,"entry_code_modif");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(identif)));   
element=lookup_widget(objet,"combobox_modif");
val=lookup_widget(objet,"entry_new_val");

strcpy(ch_element,gtk_combo_box_get_active_text(GTK_COMBO_BOX(element)));

e=int_ch(ch_element); 

strcpy(ch_value,gtk_entry_get_text(GTK_ENTRY(val)));

test=modif_transac(id,e,ch_value);

sprintf(ch,"%d",test);//gtk_label_set_text(GTK_LABEL(pt),ch);

    
	    if (strcmp(ch,"1")==0)
		{ 
		 
		    sprintf(ch,"Modification reussie!");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}
	    else
		{
			
		    sprintf(ch,"ERREUR: identifiant inexistant");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		} 


}

////////////////////////////////////////////////////////////////////////
void
on_button_retour2_modif_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal1 ;

GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"modif_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"supprimer_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"affichage_exep");

menuprincipal1=create_acceuil_finance();
gtk_widget_show (menuprincipal1);
}

////////////////////////////////////////////////////////////////////////
void
on_button_valider_supprimer_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* code_transac,*window_supp;
GtkWidget* pt;
 char id[20], ch[50]; int test;
window_supp=lookup_widget(objet,"supprimer_transac");
code_transac=lookup_widget(objet,"entry_code_supp_transac");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(code_transac)));
pt=lookup_widget (objet , "sortie_supp_transac");
test=supprimer_transac(id);
sprintf(ch,"%d",test);

    
	    if (strcmp(ch,"1")==0)
		{ 
		    
		    sprintf(ch,"Supression reussie");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}
	    else
		{
		    sprintf(ch,"ERREUR: ID inexistant");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		} 

}

////////////////////////////////////////////////////////////////////////
void
on_button_retour4_transac_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal ;

GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"modif_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"supprimer_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"affichage_exep");

menuprincipal=create_acceuil_finance();
gtk_widget_show (menuprincipal);
}

////////////////////////////////////////////////////////////////////////
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* code_transaction;
gchar* nom;
gchar* type;
gchar* objet;
gchar* jj;
gchar* mm;
gchar* aa;
gchar* montant;
transaction T;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter,path))
{
//obtenir les valeurs de la ligne selectionnée

gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&code_transaction,2,&nom,3,&jj,4,&mm,5,&aa,6,&objet,7,&montant,8,&type,-1);

strcpy(T.code_transac,code_transaction);
strcpy(T.nom,nom);
strcpy(T.date.jour,jj);
strcpy(T.date.mois,mm);
strcpy(T.date.annee,aa);
strcpy(T.objet,objet);
strcpy(T.montant,montant);
strcpy(T.type,type);
}
}

////////////////////////////////////////////////////////////////////////
void
on_buttonretou5_transac_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal3 ;

GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"modif_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"supprimer_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"affichage_exep");

menuprincipal3=create_acceuil_finance();
gtk_widget_show (menuprincipal3);
}


void
on_chercher_nbr_facture_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE* f; char ch[50];
int m,a,test; char chc[20],chnb[20];
char ch1[20],ch2[20],ch3[20],ch4[20],ch5[20],ch6[20],ch7[20],ch8[20];
int nb=0;
   
    GtkWidget *N,*pt;
    GtkWidget *affichage;
    affichage=lookup_widget(objet,"affichage_transac");

    N=lookup_widget(objet,"entry_code_client_ch");
	strcpy(chc,gtk_entry_get_text(GTK_ENTRY(N)));

   	 pt=lookup_widget (objet ,"sortie_nbr_facture");


test=finance_ajout1(chc);
f=fopen("transac.txt","r");
if (f!=NULL)
{
         while (fscanf (f, "%s %s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7,ch8)!=EOF)
            {
	if (strcmp(chc,ch2)==0)

	{

		nb++ ;
	}
}}
fclose(f);
		if (nb==0)
{
		    sprintf(ch,"Pas de Facture ");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
}

else	{ 
sprintf(chnb,"%d",nb);
gtk_label_set_text(GTK_LABEL(pt),chnb);
	}
}


void
on_affichage_facture_client_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowaffich ;
GtkWidget *fenetre_aff;
GtkWidget *treeview2;

fenetre_aff=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(fenetre_aff);
windowaffich=lookup_widget(objet,"affichage_exep");


GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"modif_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"supprimer_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"acceuil_finance");

windowaffich=create_affichage_exep();
gtk_widget_show (windowaffich);

treeview2=lookup_widget(windowaffich,"treeview2");
afficher_transac1(treeview2);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* code_transaction;
gchar* nom;
gchar* type;
gchar* objet;
gchar* jj;
gchar* mm;
gchar* aa;
gchar* montant;
transaction T;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter,path))
{
//obtenir les valeurs de la ligne selectionnée

gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&code_transaction,2,&nom,3,&jj,4,&mm,5,&aa,6,&objet,7,&montant,8,&type,-1);

strcpy(T.code_transac,code_transaction);
strcpy(T.nom,nom);
strcpy(T.date.jour,jj);
strcpy(T.date.mois,mm);
strcpy(T.date.annee,aa);
strcpy(T.objet,objet);
strcpy(T.montant,montant);
strcpy(T.type,type);
}
afficher_transac1(treeview);

}


void
on_retour_affichage1_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal3 ;

GtkWidget *windowf1,* windowf2,* windowf3,* windowf4,* windowf5 ;
windowf1=lookup_widget(objet,"affichage_transac");
gtk_widget_destroy(windowf1);
windowf2=lookup_widget(objet,"modif_transac");
gtk_widget_destroy(windowf2);
windowf3=lookup_widget(objet,"ajout_transac");
gtk_widget_destroy(windowf3);
windowf4=lookup_widget(objet,"supprimer_transac");
gtk_widget_destroy(windowf4);
windowf5=lookup_widget(objet,"affichage_exep");

menuprincipal3=create_acceuil_finance();
gtk_widget_show (menuprincipal3);
}

