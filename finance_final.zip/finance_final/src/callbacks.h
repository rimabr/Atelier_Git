#include <gtk/gtk.h>


void
on_ajouter_transac_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_transac_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_transac_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_transac_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour1_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_valider_transac_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_chercher_modif_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_valider_modif_transac_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour2_modif_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_valider_supprimer_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour4_transac_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonretou5_transac_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_nbr_facture_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_affichage_facture_client_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_affichage1_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);
