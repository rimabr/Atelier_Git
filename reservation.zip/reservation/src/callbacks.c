#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reservation.h"
#include <string.h>
#include <stdio.h>

void
on_espace_client_reservation_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowespace_client ;


GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"modif_reservatin");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR6);



windowespace_client=create_bienvenue_client_resevation();
gtk_widget_show (windowespace_client);
}


void
on_espace_admin_reservation_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowespace_admin ;

GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"modif_reservatin");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR6);

windowespace_admin=create_bienvenue_admin_reservation();
gtk_widget_show (windowespace_admin);
}


void
on_valider_reservation_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE* f; reservation R; char ch[50];
int j,m,a,i; char chj[20],chm[20],cha[20],code[20],chcc[20],chcontrol[50];
int test=0; char chc[20],chn[20];
int test1 ;
int test2,test3 ;
int n=0;
test3=0;
   
    GtkWidget *C,*N,*NM,*J,*M,*A,*H,*pt,*control;
    GtkWidget *ajouter_reser;
    ajouter_reser=lookup_widget(objet,"ajout_reservation");
    N=lookup_widget(objet,"entry_nom_reservation");
    NM=lookup_widget(objet,"entry_numero_reservation");
    H=lookup_widget(objet,"combobox_heure_reservation");
    J=lookup_widget(objet,"spinbutton_jour_reservation");
    M=lookup_widget(objet,"spinbutton_mois_reservation");
    A=lookup_widget(objet,"spinbutton_annee_reservation");
    pt=lookup_widget (objet ,"sortie_reservation");
    control=lookup_widget (objet ,"entry_erreur_num");


j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(J)); sprintf(chj,"%d",j);
m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(M)); sprintf(chm,"%d",m);
a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(A)); sprintf(cha,"%d",a);

strcpy(R.nom_client,gtk_entry_get_text(GTK_ENTRY(N)));
strcpy(R.numero,gtk_entry_get_text(GTK_ENTRY(NM)));
if((strlen(R.numero)!=8)||(atoi(R.numero)==0))
test3=1;


strcpy(code,"R1");	 
f=fopen("reservation.txt","r");
if (f!=NULL)
{
	while (fscanf(f,"%s %*s %*s %*s %*s %*s %*s \n",chc)!=EOF)
{



for (i=1;i<=20;i++)
{
chcc[i-1]=chc[i];
}
chcc[i-1]='\0';

n=atoi(chcc);
n=n+1;
strcpy(code,"R");
sprintf(chn,"%d",n);
strcat(code,chn);
}
fclose(f);		
}



strcpy(R.code_reser,code);

strcpy(R.heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(H)));

strcpy(R.date.jour,chj);
strcpy(R.date.mois,chm);
strcpy(R.date.annee,cha);
test1= R_trouve(R.code_reser);
test2= R_trouvenom(R.nom_client);

		if (test3==1)
			{
				sprintf(chcontrol,"ERREUR!!");
				gtk_label_set_text(GTK_LABEL(control),chcontrol);

			}
    
	    if ((test1==0)&&(test2==0)&&(test3==0))
		{ 
		    ajouter_reservation(R);
		    sprintf(ch,"Ajout reussi");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		}
	    else
		{

		    sprintf(ch,"ERREUR:Reservation deja existant");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		}

}

		   


void
on_retour_reservation1_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowacceuil ;

GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"modif_reservatin");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR6);

windowacceuil=create_bienvenue_reservation();
gtk_widget_show (windowacceuil);
}


void
on_modifier_reservation_client_clicked (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowmodif ;

GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"bienvenue_reservation");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR6);

windowmodif=create_modif_reservatin();
gtk_widget_show (windowmodif);
}


void
on_ajouter_reservation_client_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowajout ;

GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"modif_reservatin");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"bienvenue_reservation");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR6);

windowajout=create_ajout_reservation();
gtk_widget_show (windowajout);
}


void
on_chercher_code_modif_reservation_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* name,*pt; char nn [25],ch[40];
char ch1[20],ch2[20],ch3[20],ch4[20],ch5[20],ch6[20],ch7[20];
GtkWidget *n, *jj, *mm, *aa, *nm, *hh;
FILE* f;
f=fopen("reservation.txt","r");
name=lookup_widget(objet,"entry_code_reservation_modif");
strcpy(nn,gtk_entry_get_text(GTK_ENTRY(name)));   
n=lookup_widget(objet,"sortie_nom_client_reservation");
nm=lookup_widget(objet,"sortie_numero_client_reservation");
jj=lookup_widget(objet,"sortie_jour_reservation");
mm=lookup_widget(objet,"sortie_mois_reservation");
aa=lookup_widget(objet,"sortie_annee_reservation");
hh=lookup_widget(objet,"sortie_heure_reservation");
pt=lookup_widget(objet,"sortie_code_reservation_recherche");


    
	if (f!=NULL)
{

         while (fscanf (f, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7)!=EOF)
            {
	if (strcmp(nn,ch2)==0)
	{

			sprintf(ch,"Identifiant existant!");
		    	gtk_label_set_text(GTK_LABEL(pt),ch);

			gtk_label_set_text(GTK_LABEL(n),ch2);
			gtk_label_set_text(GTK_LABEL(nm),ch3);
			gtk_label_set_text(GTK_LABEL(jj),ch4);
			gtk_label_set_text(GTK_LABEL(mm),ch5);
			gtk_label_set_text(GTK_LABEL(aa),ch6);
			gtk_label_set_text(GTK_LABEL(hh),ch7);
	}
		}
	fclose(f);
		}
	    else
		{
		    sprintf(ch,"Pas de reservation!");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		}
}


void
on_valider_modif_reservation_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char ch_element[20],ch_value[20],id[20],ch[50]; int e,test;

	GtkWidget *element,*val,*identif,*pt;

pt=lookup_widget(objet,"sortie_modif_reservation");
identif=lookup_widget(objet,"entry_code_reservation_modif");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(identif)));   
element=lookup_widget(objet,"combobox_modif_reservation");
val=lookup_widget(objet,"entry_new_val_reservation");

strcpy(ch_element,gtk_combo_box_get_active_text(GTK_COMBO_BOX(element)));

e=int_ch(ch_element); 

strcpy(ch_value,gtk_entry_get_text(GTK_ENTRY(val)));

test=modif_reservation(id,e,ch_value);

sprintf(ch,"%d",test);//gtk_label_set_text(GTK_LABEL(pt),ch);

    
	    if (strcmp(ch,"1")==0)
		{ 
		 
		    sprintf(ch,"Modification reussie!");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}
	    else
		{
			
		    sprintf(ch,"ERREUR: identifiant inexistant");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		} 

}


void
on_retour_modif_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowacceuil ;

GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"modif_reservatin");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR6);

windowacceuil=create_bienvenue_reservation();
gtk_widget_show (windowacceuil);
}


void
on_modif_accueil_admin_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowmodif ;

GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"bienvenue_reservation");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR6);

windowmodif=create_modif_reservatin();
gtk_widget_show (windowmodif);
}


void
on_afficher_reservation_admin_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowaffich ;
GtkWidget *fenetre_ajout;
GtkWidget *treeview1;

fenetre_ajout=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(fenetre_ajout);
windowaffich=lookup_widget(objet,"affichage_reservation");

GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"bienvenue_reservation");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"modif_reservatin");
gtk_widget_destroy(windowR6);

windowaffich=create_affichage_reservation();
gtk_widget_show (windowaffich);

treeview1=lookup_widget(windowaffich,"treeview1");
afficher_reservation(treeview1);
}


void
on_supprimer_reservation_admin_clicked (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowsupp ;

GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"bienvenue_reservation");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"modif_reservatin");
gtk_widget_destroy(windowR6);

windowsupp=create_supp_reservation_admi();
gtk_widget_show (windowsupp);
}


void
on_valider_supp_reservation_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* code_reser,*window_supp;
GtkWidget* pt;
 char id[20], ch[50]; int test;
window_supp=lookup_widget(objet,"supp_reservation_admi");
code_reser=lookup_widget(objet,"entry_code_reservation_supp");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(code_reser)));
pt=lookup_widget (objet , "sortie_reservation_supp");
test=supprimer_reservation(id);
sprintf(ch,"%d",test);

    
	    if (strcmp(ch,"1")==0)
		{ 
		    
		    sprintf(ch,"Supression reussie");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}
	    else
		{
		    sprintf(ch,"ERREUR: ID inexistant");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		} 
}


void
on_retour_supp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowacceuil ;

GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"modif_reservatin");
gtk_widget_destroy(windowR6);

windowacceuil=create_bienvenue_reservation();
gtk_widget_show (windowacceuil);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* code_reser;
gchar* nom_client;
gchar* numero;
gchar* heure;
gchar* jj;
gchar* mm;
gchar* aa;

reservation R;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter,path))
{
//obtenir les valeurs de la ligne selectionnée


gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&code_reser,2,&nom_client,3,&numero,4,&jj,5,&mm,6,&aa,7,&heure,-1);
strcpy(R.code_reser,code_reser);
strcpy(R.nom_client,nom_client);
strcpy(R.numero,numero);
strcpy(R.date.jour,jj);
strcpy(R.date.mois,mm);
strcpy(R.date.annee,aa);
strcpy(R.heure,heure);

}
}


void
on_retour_affichage_reservation_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowacceuil ;
GtkWidget *windowR1,* windowR2,* windowR3,* windowR4,* windowR5,*windowR6;
windowR1=lookup_widget(objet,"bienvenue_admin_reservation");
gtk_widget_destroy(windowR1);
windowR2=lookup_widget(objet,"ajout_reservation");
gtk_widget_destroy(windowR2);
windowR3=lookup_widget(objet,"modif_reservatin");
gtk_widget_destroy(windowR3);
windowR4=lookup_widget(objet,"bienvenue_client_resevation");
gtk_widget_destroy(windowR4);
windowR5=lookup_widget(objet,"supp_reservation_admi");
gtk_widget_destroy(windowR5);
windowR6=lookup_widget(objet,"affichage_reservation");
gtk_widget_destroy(windowR6);
windowacceuil=create_bienvenue_reservation();
gtk_widget_show (windowacceuil);
}

