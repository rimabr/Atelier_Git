typedef struct
{
    char mois [20];
    char jour[20];
    char annee [20];
}date;
typedef struct
{
    char code_reser[20];
    char nom_client[20];
    date date;
    char heure [20];
    char numero[20];
}reservation;


void ajouter_reservation(reservation R);
int supprimer_reservation(char code_sup[]);
int modif_reservation(char code_modif[],int element,char val[] ); 
int afficher_reservation(GtkWidget* liste);
int R_trouve(char code[]);
int R_trouvenom(char nom[]);
int int_ch(char ch[]);
//char code_reser(char code[20]);
