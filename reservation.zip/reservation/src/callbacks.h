#include <gtk/gtk.h>


void
on_espace_client_reservation_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_espace_admin_reservation_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_reservation_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_reservation1_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_reservation_client_clicked (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_reservation_client_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_code_modif_reservation_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_modif_reservation_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_modif_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modif_accueil_admin_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_reservation_admin_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_reservation_admin_clicked (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_supp_reservation_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_supp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_affichage_reservation_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);
