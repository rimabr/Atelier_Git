#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "reservation.h"

enum{
CODE_RESER,
NOM_CLIENT,
JOUR,
MOIS,
ANNEE,
HEURE,
NUMERO,
COLUMNS
};

void ajouter_reservation(reservation R)
{
   FILE *f ;
  f=fopen("reservation.txt","a+");
    if (f!=NULL)
	{
	fprintf(f,"%s %s %s %s %s %s %s \n",R.code_reser,R.nom_client,R.numero,R.date.jour,R.date.mois,R.date.annee,R.heure);

    	}
    fclose(f);

}
////////////////////////////////////////////////////////////////////////////
int R_trouve(char code[])
{
	FILE* f; int test=0; char ch[30];
	f=fopen("reservation.txt","r");
if (f!=NULL)
{
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s \n",ch)!=EOF)
		{	
			if (strcmp(code,ch)==0)
				test=1;
		}
}
fclose(f);
return test;
}

////////////////////////////////////////////////////////////////////////////
/*char code_reser(char code[20])

{

	FILE* f; int test=0; char ch[20],chn[20];

	f=fopen("reservation.txt","r");
	int n ;
if (f!=NULL)
{
	while (fscanf(f,"%s %*s %*s %*s %*s %*s %*s \n",ch)!=EOF)
{
n=atoi(ch);
n=n+1;
strcpy(code,"R");
sprintf(chn,"%d",n);
strcat(code,chn);
}
fclose(f);		
}

else strcpy(code,"R1");

return code;
}*/

////////////////////////////////////////////////////////////////////////////

int R_trouvenom(char nom[])
{
	FILE* f; int test=0; char ch[20];
	f=fopen("reservation.txt","r");
if (f!=NULL)
{
	while(fscanf(f,"%*s %s %*s %*s %*s %*s %*s \n",ch)!=EOF)
		{	
			if (strcmp(nom,ch)==0)
				test=1;
		}
}
fclose(f);
return test;
}
////////////////////////////////////////////////////////////////////////////
int supprimer_reservation(char code_sup[])
{
    FILE* fw;
    FILE* f; int test=0;
    char ch1[20],ch2[20],ch3[20],ch4[20],ch5[20],ch6[20],ch7[20];
    f=fopen("reservation.txt","r"); fw=fopen("reservation_aux.txt","a");
    if (fw!=NULL && f!=NULL)
    {
         while (fscanf (f, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7)!=EOF)
            {
                if (strcmp (ch1, code_sup) != 0)
                fprintf (fw,"%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7);
                else
                    test=1; //supression etablie.
            }

    }
    else
        return(0) ;

    fclose(fw);
    fclose(f);
   remove("reservation.txt");
   rename("reservation_aux.txt","reservation.txt");
return test;}
////////////////////////////////////////////////////////////////////////////

int modif_reservation(char code_modif[],int element,char val[] )
{
FILE* fw;
    FILE* f; int test=0;

    char ch1[20],ch2[20],ch3[20],ch4[20],ch5[20],ch6[20],ch7[20];
    f=fopen("reservation.txt","r"); fw=fopen("reservation_aux.txt","a");
    if (fw!=NULL && f!=NULL)
     {
         while (fscanf (f, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7)!=EOF)
            {
                if (strcmp (ch1, code_modif) == 0)
                {
                    test=1;
                    switch (element)
                    {

                        case 0:
                            fprintf (fw, "%s %s %s %s %s %s %s \n",val,ch2,ch3,ch4,ch5,ch6,ch7);
                            break;
                        case 1:
                            fprintf (fw, "%s %s %s %s %s %s %s \n",ch1,val,ch3,ch4,ch5,ch6,ch7);
                            break;
                        case 2:
                            fprintf (fw, "%s %s %s %s %s %s %s \n",ch1,ch2,val,ch4,ch5,ch6,ch7);
                            break;
                        case 3:
                            fprintf (fw, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,val,ch5,ch6,ch7);
                            break;
                        case 4:
                            fprintf (fw, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,val,ch6,ch7);
                            break;
                        case 5:
                            fprintf (fw, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,val,ch7);
                            break;
                        case 6:
                            fprintf (fw, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,val);
                            break;                          

                    }
                }
                    else
                     fprintf (fw, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7);

            }

}
fclose(f); fclose(fw);
 remove("reservation.txt");
 rename("reservation_aux.txt","reservation.txt");

return test;
}
////////////////////////////////////////////////////////////////////////////
int int_ch(char ch[])
{

if (ch[0]=='1')
	return 1;
else if (ch[0]=='2')
	return 2;
else if (ch[0]=='3')
	return 3;
else if (ch[0]=='4')
	return 4;
else if (ch[0]=='5')
	return 5;
else if (ch[0]=='6')
	return 6;
else if (ch[0]=='7')
	return 7;

else return (-1);

}
////////////////////////////////////////////////////////////////////////////
int afficher_reservation(GtkWidget* liste)
{


GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de 		chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son 		attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de 		treeview
	GtkListStore  *store;    //l'enregistrement de treeview

	 char code_reser[20];
         char nom_client[20];
         char jour[20];
         char mois[20],annee[20],heure[20],numero[20];



	
	 store=NULL;
	 FILE *F;

	store=gtk_tree_view_get_model(liste);//va prendre comme variable de la liste
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new (); //cellule contenant du texte
	column = gtk_tree_view_column_new_with_attributes("Code_reser", 		renderer,"text",CODE_RESER,NULL);//creation d'une colonne avec du 		texte
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);//associer 		la colonne à l'afficher (GtkTreeView);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Nom_client", 		  renderer,"text",NOM_CLIENT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Jour", 		  renderer,"text",JOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Mois", 		renderer,"text",MOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Annee", 			renderer,"text",ANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Heure", 			renderer,"text",HEURE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Numero", 			renderer,"text",NUMERO,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}

//lA liste contient 7 colonnes de type chaine de caracteres
	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);
F=fopen("reservation.txt","r");
if(F==NULL)
{
	return;
}
else
{ 
   F=fopen("reservation.txt","a+");
   while(fscanf(F,"%s %s %s %s %s %s %s \n",code_reser,nom_client,numero,jour,mois,annee,heure)!=EOF)
{       

        	
gtk_list_store_append (store, &iter);//variable intermediaire store
gtk_list_store_set (store, &iter,CODE_RESER,code_reser,NOM_CLIENT,nom_client,NUMERO,numero,JOUR,jour,MOIS,mois,ANNEE,annee,HEURE,heure, -1);//correspondre chaque champ a mon variable
}
	fclose(F);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));//

	g_object_unref (store);
}

}







