#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "plantation.h"
#include <string.h>
#include <stdio.h>
int choix[]={0,1};

void
on_ajout_plante_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowajouter;

GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5 ;
windowpl1=lookup_widget(objet,"menu_plantation");
gtk_widget_destroy(windowpl1);

windowpl2=lookup_widget(objet,"modifier_plante");
gtk_widget_destroy(windowpl2);
windowpl3=lookup_widget(objet,"suppression_plante");
gtk_widget_destroy(windowpl3);
windowpl4=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(windowpl4);
windowpl5=lookup_widget(objet,"window_affichage_exep");
gtk_widget_destroy(windowpl5);

windowajouter=create_ajouter_plante();
gtk_widget_show (windowajouter);
}


void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowmodifier ;

GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5;

windowpl1=lookup_widget(objet,"menu_plantation");
gtk_widget_destroy(windowpl1);

windowpl2=lookup_widget(objet,"ajouter_plante");
gtk_widget_destroy(windowpl2);
windowpl3=lookup_widget(objet,"suppression_plante");
gtk_widget_destroy(windowpl3);
windowpl4=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(windowpl4);
windowpl5=lookup_widget(objet,"window_affichage_exep");
gtk_widget_destroy(windowpl5);
windowmodifier=create_modifier_plante();
gtk_widget_show (windowmodifier);
}


void
on_supprimer_plante_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowsupp;

GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5 ;
windowpl1=lookup_widget(objet,"menu_plantation");
gtk_widget_destroy(windowpl1);

windowpl3=lookup_widget(objet,"ajouter_plante");
gtk_widget_destroy(windowpl3);
windowpl2=lookup_widget(objet,"modifier_plante");
gtk_widget_destroy(windowpl2);

windowpl4=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(windowpl4);
windowpl5=lookup_widget(objet,"window_affichage_exep");
gtk_widget_destroy(windowpl5);

windowsupp=create_suppression_plante();
gtk_widget_show (windowsupp);
}


void
on_afficher_plante_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowaffich ;
GtkWidget *fenetre_ajout;
GtkWidget *treeview1;


GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5;

windowpl1=lookup_widget(objet,"menu_plantation");
gtk_widget_destroy(windowpl1);

windowpl4=lookup_widget(objet,"ajouter_plante");
gtk_widget_destroy(windowpl4);
windowpl2=lookup_widget(objet,"modifier_plante");
gtk_widget_destroy(windowpl2);
windowpl3=lookup_widget(objet,"suppression_plante");
gtk_widget_destroy(windowpl3);

windowpl5=lookup_widget(objet,"window_affichage_exep");
gtk_widget_destroy(windowpl5);



windowaffich=lookup_widget(objet,"affichage_plantes");
windowaffich=create_affichage_plantes();
gtk_widget_show (windowaffich);


treeview1=lookup_widget(windowaffich,"treeview1");
afficher_plant(treeview1);

}

//////////////////////////////////////////////////////////////
void
on_valider_plante_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE* f; plante p; char ch[50];
int j,m,a,s; char chj[20],chm[20],cha[20],chs[20],text[20];
   
    GtkWidget *C,*N,*T,*S,*J,*M,*A,*E,*pt;
    GtkWidget *ajouter_plante;
    ajouter_plante=lookup_widget(objet,"ajouter_plante");
    C=lookup_widget(objet,"entry_code_plante");
    N=lookup_widget(objet,"nom_plante");
    S=lookup_widget(objet,"spinbutton_stock");
    T=lookup_widget(objet,"combobox_type");
    J=lookup_widget(objet,"spinbutton_j");
    M=lookup_widget(objet,"spinbutton_m");
    A=lookup_widget(objet,"spinbutton_a");

    pt=lookup_widget (objet ,"label_sortie_ajout_plante");
j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(J)); sprintf(chj,"%d",j);
m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(M)); sprintf(chm,"%d",m);
a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(A)); sprintf(cha,"%d",a);
s=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(S)); sprintf(chs,"%d",s);
strcpy(p.code_plant,gtk_entry_get_text(GTK_ENTRY(C)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(N)));
strcpy(p.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(T)));

strcpy(p.date.jour,chj);
strcpy(p.date.mois,chm);
strcpy(p.date.annee,cha);
strcpy(p.quantite,chs);


	
	
    
	    if (P_trouve(p.code_plant)==0)
		{ 
		    ajouter_plant (p);
		    sprintf(ch,"Ajout reussi");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}
	    else if (P_trouve(p.code_plant)!=0)
		{
		    sprintf(ch,"ERREUR: plante deja existante");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		}

		else 
{ 
		    ajouter_plant (p);
		    sprintf(ch,"Ajout reussi");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}

}

///////////////////////////////////////////////////////////////////
void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal ;


GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5;
windowpl1=lookup_widget(objet,"ajouter_plante");
gtk_widget_destroy(windowpl1);
windowpl2=lookup_widget(objet,"modifier_plante");
gtk_widget_destroy(windowpl2);
windowpl3=lookup_widget(objet,"suppression_plante");
gtk_widget_destroy(windowpl3);
windowpl4=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(windowpl4);
windowpl5=lookup_widget(objet,"window_affichage_exep");
gtk_widget_destroy(windowpl5);


menuprincipal=create_menu_plantation();
gtk_widget_show (menuprincipal);

}


void
on_valid_modif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
char ch_element[20],ch_value[20],id[20],ch[40]; int e,test;

	GtkWidget *element,*val,*identif,*pt;

pt=lookup_widget(objet,"label_sortie_modif_P");
identif=lookup_widget(objet,"code_modif");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(identif)));   
element=lookup_widget(objet,"infoP_modif");
val=lookup_widget(objet,"entry_modifP");

strcpy(ch_element,gtk_combo_box_get_active_text(GTK_COMBO_BOX(element)));
//c=int_ch(ch_element); //sprintf(ch,"%d",e);
//strcpy(ch,ch_element[0]);
//sscanf(&ch,"%d",e); sprintf(ch,"%d",e);
e=int_ch(ch_element); //sprintf(ch," %d",e);
		  //  gtk_label_set_text(GTK_LABEL(pt),ch);
strcpy(ch_value,gtk_entry_get_text(GTK_ENTRY(val)));

test=modif_plantation(id,e,ch_value);

sprintf(ch,"%d",test);//gtk_label_set_text(GTK_LABEL(pt),ch);

    
	    if (strcmp(ch,"1")==0)
		{ 
		 
		    sprintf(ch,"Modification reussie!");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}
	    else
		{
			
		    sprintf(ch,"ERREUR: identifiant inexistant");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		} 




/*GtkWidget *windowaffich;
windowaffich=create_affichage_plantes();
gtk_widget_show (windowaffich);*/
}


void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal1;

GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5;
windowpl1=lookup_widget(objet,"ajouter_plante");
gtk_widget_destroy(windowpl1);
windowpl2=lookup_widget(objet,"modifier_plante");
gtk_widget_destroy(windowpl2);
windowpl3=lookup_widget(objet,"suppression_plante");
gtk_widget_destroy(windowpl3);
windowpl4=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(windowpl4);
windowpl5=lookup_widget(objet,"window_affichage_exep");
gtk_widget_destroy(windowpl5);

menuprincipal1=create_menu_plantation();

gtk_widget_show (menuprincipal1);
}


void
on_valider_supp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* code_plante,*window_supp;
GtkWidget* pt;
 char id[20], ch[50]; int test;
window_supp=lookup_widget(objet,"suppression_plante");
code_plante=lookup_widget(objet,"code_supp");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(code_plante)));
pt=lookup_widget (objet , "label_sortie_supp");
test=supprimer_plant(id);
sprintf(ch,"%d",test);

    
	    if (strcmp(ch,"1")==0)
		{ 
		    
		    sprintf(ch,"Supression reussie");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}
	    else
		{
		    sprintf(ch,"ERREUR: ID inexistant");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		} 

}


/*
windowaffich=create_affichage_plantes();
gtk_widget_show (windowaffich);*/



void
on_Retour3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal2;

GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5;
windowpl1=lookup_widget(objet,"ajouter_plante");
gtk_widget_destroy(windowpl1);
windowpl2=lookup_widget(objet,"modifier_plante");
gtk_widget_destroy(windowpl2);
windowpl3=lookup_widget(objet,"suppression_plante");
gtk_widget_destroy(windowpl3);
windowpl4=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(windowpl4);
windowpl5=lookup_widget(objet,"window_affichage_exep");
gtk_widget_destroy(windowpl5);

menuprincipal2=create_menu_plantation();
gtk_widget_show (menuprincipal2);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar* code_plant;
gchar* nom;
gchar* type;
gchar* jj;
gchar* mm;
gchar* aa;
gchar* quantite;
plante p;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* window_modif,*pt;

if (gtk_tree_model_get_iter(model, &iter,path))
{
//obtenir les valeurs de la ligne selectionnée

gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&code_plant,2,&nom,3,&type,4,&jj,5,&mm,6,&aa,7,&quantite,-1);


strcpy(p.code_plant,code_plant);
strcpy(p.nom,nom);
strcpy(p.type,type);
strcpy(p.date.jour,jj);
strcpy(p.date.mois,mm);
strcpy(p.date.annee,aa);
strcpy(p.quantite,quantite);

//appel de la fct de suppression
supprimer_plant(code_plant);


//màj du treeview
afficher_plant(treeview);



}
}





////////////////////////////////////

void
on_retour4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal3,*aff ;
GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5;
windowpl1=lookup_widget(objet,"ajouter_plante");
gtk_widget_destroy(windowpl1);
windowpl2=lookup_widget(objet,"modifier_plante");
gtk_widget_destroy(windowpl2);
windowpl3=lookup_widget(objet,"suppression_plante");
gtk_widget_destroy(windowpl3);
windowpl4=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(windowpl4);
windowpl5=lookup_widget(objet,"window_affichage_exep");
gtk_widget_destroy(windowpl5);
menuprincipal3=create_menu_plantation();
gtk_widget_show (menuprincipal3);
}


/////////////////////////////////////////////////////////////////

void
on_recherche_code_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* identif,*pt; char id [25],ch[40]; int test;
char ch1[20],ch2[20],ch3[20],ch4[20],ch5[20],ch6[20],ch7[20];
GtkWidget *ty, *n, *jj, *mm, *aa, *et, *st;
FILE* f;
f=fopen("plante.txt","r");
identif=lookup_widget(objet,"code_modif");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(identif)));   
ty=lookup_widget(objet,"type_sortie");
n=lookup_widget(objet,"nom_sortie");
jj=lookup_widget(objet,"jour_sortie");
mm=lookup_widget(objet,"mois_sortie");
aa=lookup_widget(objet,"annee_sortie");
st=lookup_widget(objet,"stock_sortie");
pt=lookup_widget(objet,"label_sortie_valid");

	if (f!=NULL)
{
         while (fscanf (f, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7)!=EOF)
            {
	if (strcmp(id,ch1)==0)
	{
			 sprintf(ch,"Identifiant existant!");
		    	 gtk_label_set_text(GTK_LABEL(pt),ch);

			gtk_label_set_text(GTK_LABEL(n),ch2);
			gtk_label_set_text(GTK_LABEL(ty),ch3);
			gtk_label_set_text(GTK_LABEL(jj),ch4);
			gtk_label_set_text(GTK_LABEL(mm),ch5);
			gtk_label_set_text(GTK_LABEL(aa),ch6);
			gtk_label_set_text(GTK_LABEL(st),ch7);
	}	}
	fclose(f);
		}
	    else
		{
		    sprintf(ch,"ERREUR:non existant.");
		    gtk_label_set_text(GTK_LABEL(pt),ch);

		} 
}




/////////////////////////////////////////////////////////////////


void
on_button_cherche_nombre_plantation_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE* f; plante p; char ch[50];
int m,a,test; char chm[20],cha[20],chnb[20];
char ch1[20],ch2[20],ch3[20],ch4[20],ch5[20],ch6[20],ch7[20];
int nb=0;
   
    GtkWidget *J,*M,*A,*pt;
    GtkWidget *affichage;
    affichage=lookup_widget(objet,"affichage_plantes");

    M=lookup_widget(objet,"spinbutton_mois_chercher");
    A=lookup_widget(objet,"spinbutton_annee_chercher");

    pt=lookup_widget (objet ,"sortie_nombre_de_plantation");

m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(M)); sprintf(chm,"%d",m);
a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(A)); sprintf(cha,"%d",a);
test=pl_ajout1(chm,cha);
f=fopen("plante.txt","r");
if (f!=NULL)
{
         while (fscanf (f, "%s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7)!=EOF)
            {
	if (strcmp(chm,ch5)==0&&strcmp(cha,ch6)==0)

	{

		nb++ ;
	}
}}
fclose(f);
		if (nb==0)
{
		    sprintf(ch,"Pas de plantation cette mois");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
}

else	{ 
sprintf(chnb,"%d",nb);
gtk_label_set_text(GTK_LABEL(pt),chnb);
	}
}

/////////////////////////////////////////////////////////////////
void
on_afficher_nbr_plantation_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *windowaffich ;
GtkWidget *fenetre_ajout;
GtkWidget *treeview2;


GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5;
windowpl1=lookup_widget(objet,"ajouter_plante");
gtk_widget_destroy(windowpl1);
windowpl2=lookup_widget(objet,"modifier_plante");
gtk_widget_destroy(windowpl2);
windowpl3=lookup_widget(objet,"suppression_plante");
gtk_widget_destroy(windowpl3);
windowpl4=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(windowpl4);
windowpl5=lookup_widget(objet,"menu_plantation");
gtk_widget_destroy(windowpl5);




windowaffich=lookup_widget(objet,"window_affichage_exep");
windowaffich=create_window_affichage_exep();
gtk_widget_show (windowaffich);


treeview2=lookup_widget(windowaffich,"treeview_aff");
afficher_plant1(treeview2);


/*
GtkWidget *window_affich1, *affichage ,*E_treeview,*M,*A,*pt;
int test; char ch[40];
char chm[20],cha[20];

M=lookup_widget(objet,"spinbutton_mois_chercher");
A=lookup_widget(objet,"spinbutton_annee_chercher");

M=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(M)); sprintf(chm,"%d",M);
A=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(A)); sprintf(cha,"%d",A);

test=pl_ajout1(chm,cha);

window_affich1=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(window_affich1);

affichage=create_window_affichage_exep();
gtk_widget_show(affichage);

E_treeview=lookup_widget(affichage,"treeview_aff");

afficher_plant1(E_treeview);
pt=lookup_widget(objet,"sortie_affichage_nombre_plantation");


    
	    if (test==1)
		{ 
		    
		    sprintf(ch,"Plantation pour cette mois!");
		    gtk_label_set_text(GTK_LABEL(pt),ch);
		}
	    else
		{
		    sprintf(ch,"Pas de plantation cette mois");
		    gtk_label_set_text(GTK_LABEL(pt),ch); 

		}*/
}

/////////////////////////////////////////////////////////////////
void
on_treeview_aff_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* code_plant;
gchar* nom;
gchar* type;
gchar* jj;
gchar* mm;
gchar* aa;
gchar* quantite;
plante p;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* window_modif,*pt;

if (gtk_tree_model_get_iter(model, &iter,path))
{
//obtenir les valeurs de la ligne selectionnée

gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&code_plant,2,&nom,3,&type,4,&jj,5,&mm,6,&aa,7,&quantite,-1);


strcpy(p.code_plant,code_plant);
strcpy(p.nom,nom);
strcpy(p.type,type);
strcpy(p.date.jour,jj);
strcpy(p.date.mois,mm);
strcpy(p.date.annee,aa);
strcpy(p.quantite,quantite);

//appel de la fct de suppression
supprimer_plant(code_plant);


//màj du treeview
afficher_plant1(treeview);



}
}


void
on_retour_affichage_exep_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menuprincipal ;

GtkWidget *windowpl1,* windowpl2,* windowpl3,* windowpl4,* windowpl5;
windowpl1=lookup_widget(objet,"ajouter_plante");
gtk_widget_destroy(windowpl1);
windowpl2=lookup_widget(objet,"modifier_plante");
gtk_widget_destroy(windowpl2);
windowpl3=lookup_widget(objet,"suppression_plante");
gtk_widget_destroy(windowpl3);
windowpl4=lookup_widget(objet,"affichage_plantes");
gtk_widget_destroy(windowpl4);
windowpl5=lookup_widget(objet,"window_affichage_exep");
gtk_widget_destroy(windowpl5);

menuprincipal=create_menu_plantation();
gtk_widget_show (menuprincipal);
}

