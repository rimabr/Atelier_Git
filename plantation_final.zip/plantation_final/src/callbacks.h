#include <gtk/gtk.h>


void
on_ajout_plante_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_plante_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_plante_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_plante_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valid_modif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_supp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Retour3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_recherche_code_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_consulter_affichage_pante_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_affichage_exep_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_cherche_nombre_plantation_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_nbr_plantation_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_aff_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_affichage_exep_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);
